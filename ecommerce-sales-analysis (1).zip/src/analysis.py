
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

BASE = os.path.dirname(__file__)
DATA = os.path.join(BASE, '..', 'data', 'ecommerce_sales.csv')
OUT = os.path.join(BASE, '..', 'output')
os.makedirs(OUT, exist_ok=True)

df = pd.read_csv(DATA, parse_dates=['OrderDate'])

# Cleaning
df = df.drop_duplicates(subset=['OrderID'])
for col in ['Category','Product','Region','PaymentMethod']:
    df[col] = df[col].astype('category')

df['Month'] = df['OrderDate'].dt.to_period('M').dt.to_timestamp()

# Aggregations
monthly_sales = df.groupby('Month', as_index=False)['TotalAmount'].sum()
category_sales = df.groupby('Category', as_index=False)['TotalAmount'].sum().sort_values('TotalAmount', ascending=False)
product_sales = df.groupby('Product', as_index=False)['TotalAmount'].sum().sort_values('TotalAmount', ascending=False)
region_sales = df.groupby('Region', as_index=False)['TotalAmount'].sum().sort_values('TotalAmount', ascending=False)
payment_counts = df['PaymentMethod'].value_counts().reset_index().rename(columns={'index':'PaymentMethod', 'count':'Count'})

# Exports
monthly_sales.to_csv(os.path.join(OUT, 'monthly_sales.csv'), index=False)
category_sales.to_csv(os.path.join(OUT, 'category_sales.csv'), index=False)
product_sales.to_csv(os.path.join(OUT, 'product_sales.csv'), index=False)
region_sales.to_csv(os.path.join(OUT, 'region_sales.csv'), index=False)
payment_counts.to_csv(os.path.join(OUT, 'orders_by_payment.csv'), index=False)

# Plots
plt.figure()
plt.plot(monthly_sales['Month'], monthly_sales['TotalAmount'])
plt.title('Monthly Sales Trend')
plt.xlabel('Month')
plt.ylabel('Total Sales')
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'monthly_sales_trend.png'))
plt.close()

plt.figure()
plt.bar(category_sales['Category'].astype(str), category_sales['TotalAmount'])
plt.title('Sales by Category')
plt.xlabel('Category')
plt.ylabel('Total Sales')
plt.xticks(rotation=30, ha='right')
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'sales_by_category.png'))
plt.close()

top10_products = product_sales.head(10)
plt.figure()
plt.bar(top10_products['Product'].astype(str), top10_products['TotalAmount'])
plt.title('Top 10 Products by Sales')
plt.xlabel('Product')
plt.ylabel('Total Sales')
plt.xticks(rotation=30, ha='right')
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'top10_products.png'))
plt.close()

plt.figure()
plt.bar(payment_counts['PaymentMethod'].astype(str), payment_counts['Count'])
plt.title('Orders by Payment Method')
plt.xlabel('Payment Method')
plt.ylabel('Number of Orders')
plt.xticks(rotation=30, ha='right')
plt.tight_layout()
plt.savefig(os.path.join(OUT, 'orders_by_payment.png'))
plt.close()

# Insights
total_revenue = df['TotalAmount'].sum()
avg_order_value = df['TotalAmount'].mean()
orders = len(df)

best_month = monthly_sales.loc[monthly_sales['TotalAmount'].idxmax(), 'Month'].date()
best_category = category_sales.iloc[0]['Category']
best_region = region_sales.iloc[0]['Region']
top_product = product_sales.iloc[0]['Product']

insights = f"""
# Insights Summary

- **Total Revenue:** {total_revenue:.2f}
- **Average Order Value (AOV):** {avg_order_value:.2f}
- **Total Orders:** {orders}

- **Best Month (by sales):** {best_month}
- **Top Category:** {best_category}
- **Top Region:** {best_region}
- **Top Product:** {top_product}

## Recommendations
1. Promote {best_category} items in low-season months to stabilize revenue.
2. Bundle top products with related accessories to raise AOV.
3. Expand marketing in {best_region} and replicate campaigns in other regions.
4. Offer incentives for the second most used payment method to diversify risk.
"""

with open(os.path.join(OUT, 'INSIGHTS.md'), 'w', encoding='utf-8') as f:
    f.write(insights)

print("Analysis complete. See output/ for results.")
