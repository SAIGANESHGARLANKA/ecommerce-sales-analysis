
# Project Report: E-commerce Sales Analysis

## Objective
Analyze sales to uncover growth opportunities.

## Methods
- Data cleaning, feature engineering (date parts)
- Aggregations: monthly, category, product, region, payment
- Visualizations: trend, bars
- KPI calculation: Revenue, AOV, Orders

## Key Findings
(See `output/INSIGHTS.md` after running.)

## Recommendations
- Promote top categories in low seasons
- Bundle top products to raise AOV
- Focus on best-performing region campaigns
- Incentivize under-used payment methods
