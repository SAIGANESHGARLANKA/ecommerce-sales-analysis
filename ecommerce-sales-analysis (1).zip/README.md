
# E-commerce Sales Analysis

A complete data analyst internship project. Share this repository link in your CV.

## Project Structure
```
ecommerce-sales-analysis/
├── data/
│   └── ecommerce_sales.csv
├── notebooks/
│   └── Ecommerce_Sales_Analysis.ipynb
├── src/
│   └── analysis.py
├── output/   # generated tables and charts
└── report/
    └── Project_Report.md
```

## How to Run
1. Install Python 3.9+
2. `pip install -r requirements.txt` (requirements below)
3. Run notebook in `notebooks/` **or** run CLI:
   ```bash
   python src/analysis.py
   ```

## Requirements
- pandas
- numpy
- matplotlib

## Business Questions Answered
- Sales trends over time
- Best categories/products/regions
- Payment method preferences
- Actionable recommendations
